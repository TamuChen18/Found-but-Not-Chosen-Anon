# Data package: Found but Not Chosen

Extract this package into the root of the code repository; it adds `runs/` (generation configs and raw candidate
pools), `logs/` (per-request call logs: sampling parameters, finish reasons, token usage; no prompts, completions or
credentials), the raw prompt-matched pools and the candidate-level result files under `artifacts/`. Then run
`bash scripts/reproduce_all.sh` (see the repository `README.md`).

## License

Model outputs, logs and analysis results in this package: MIT License, Copyright (c) 2026 The Authors (the license
text is in `LICENSE` of the code repository).

The task descriptions and gold workflows contained in the candidate pools come from DisasterBench_Open (commit
`408672bf0da489d94e6245900a87ec913b3d69f9`) and remain under its MIT License (`licenses/DisasterBench_Open-LICENSE`).
